/* 
 * @file project5.cc
 * @author Zachary Wolfe (zw224021@ohio.edu)
 * @brief Create a miniature Post Office
 * @date 2022-11-28
 */
#include <vector>
#include <string>
#include <iostream>
#include <fstream>
#include <cstring>
#include <cctype>
#include "project5.h"
 
using namespace std;

// my functions
 
int calcCheckDigit(int sum);
bool isText(char line[], bool flag);
string create_barcode(Letter &ltr);

int main(){
    // variables used
    ofstream outFile;
    ofstream outFile2;
    PostOffice postalservice;
    string name;
    string neighborhood_name;
    int printwhat = 0;
    int promptselection = 0;
    int selecthome = 0;
    int selectneighborhood = 0;

    //run at most once
    do{
        // prompt
        cout << "**************************************************************" << endl;
        cout << "1. Create a new neighborhood" << endl;
        cout << "2. Enter the information for a home" << endl;
        cout << "3. Add a letter that was sent to a particular Home in a particular Neighborhood" << endl;
        cout << "4. Output all the PostOffice data (\"FinalProject.txt\")" << endl;
        cout << "5. Quit" << endl;
        cout << "**************************************************************" << endl;
        cin >> promptselection;

        switch (promptselection)
        {
        case 1:
            //if the amount of neighborhoods is == 5 then the user should no longer be allowed to add a new neighborhood
            if (postalservice.display_counter() == 5){
                    cout << "\tYou have reached the MAXIMUM amount of Homes that you can add to this Post Office." << endl;
                    break;
                }
                cout << "Enter the name of the \"NEW\" Neighborhood" << endl;
                
                // ignore any new lines, allows user to enter a whole name instead of just part of a name
                while (cin.peek() == '\n'){
                    cin.ignore();
                }
                getline(cin, name);
                //set the name of the neighborhood
                postalservice.setName(name);
                //increment the amount of neighborhoods
                postalservice.inc_counter();
                cout << "\tTotal Neighborhoods: " << postalservice.display_counter() << endl;
               
                break;
        case 2:
            // as long as there is a neighborhood initialized
            if (postalservice.display_counter() >= 1){
                // then allow the user to add a home to said neighborhood
                cout << "Please select a Neighborhood that you would like to add a home to. " << endl;
                for (int i = 0; i < postalservice.display_counter(); i++){
                    cout << "\t" << i + 1 << ". " << postalservice.getNeighborhood(i).getName() << endl;
                }
                selectneighborhood = 0;
                cin >> selectneighborhood;
                selectneighborhood -= 1;
                //prompt the user for the information on a home
                postalservice.prompt(selectneighborhood);
                cout << "\tTotal homes in Neighborhood -> \"" << postalservice.getNeighborhood(selectneighborhood).getName() << "\": " << postalservice.getNeighborhood(selectneighborhood).homes.size() << endl << endl;
                break;
            }
            else{
                //if there are no neighborhoods
                cout << "\tPlease Create a Neighborhood first. " << endl;
                break;
            }
            
        case 3:
            //if there is a neighborhood declared
            if (postalservice.display_counter() >= 1){
                //print all the neighborhoods
                cout << "Please select a Neighborhood that you would like to add a Letter to. " << endl;
                for (int i = 0; i < postalservice.display_counter(); i++){
                    cout << "\t" << i + 1 << ". " << postalservice.getNeighborhood(i).getName() << endl;
                }
                selectneighborhood = 0;
                cin >> selectneighborhood;
                selectneighborhood -= 1;
                //print all the homes if there has been a home added to said neighborhood
                if (postalservice.getNeighborhood(selectneighborhood).homes.size() >= 1){
                    cout << "Please select a Home Owner that you would like to add a Letter to their home. " << endl;
                    for (long unsigned int i = 0; i < postalservice.getNeighborhood(selectneighborhood).homes.size(); i++){
                        cout << "\t" << i + 1 << ". " << postalservice.getNeighborhood(selectneighborhood).homes[i].getAdrs().getAdrsName() << endl;
                    }
                    cin >> selecthome;
                    selecthome -= 1;
                    //prompt the user for the information on a letter
                    postalservice.getNeighborhood(selectneighborhood).prompt(postalservice.getNeighborhood(selectneighborhood), postalservice.getNeighborhood(selectneighborhood).homes[selecthome]);
                    cout << "\tTotal letters for Home -> \"" << postalservice.getNeighborhood(selectneighborhood).homes[selecthome].getAdrs().getAdrsName() << "\": "<< postalservice.getNeighborhood(selectneighborhood).homes[selecthome].getLetterSize() << endl;
                    break;
                }
                else{
                    //zero homes set
                    cout << "\tTry adding a Home to this Neighborhood first. " << endl;
                    break;
                }
            }
            else{
                //no neighborhood set
                cout << "\tPlease Create a Neighborhood first. " << endl;
                break;
            }
        case 4:
            //select between printing all the post office data or just a specific home
            cout << "\t1. Print all Post Office Data. \n\t2. Print a specific piece of Post Office Data. " << endl;
            cin >> printwhat;
            if (printwhat == 1){
                outFile.open("FinalProject.txt");
                outFile << "\tPost Office General Information Report" << endl;
                outFile << "------------------------------------------" << endl;
                //run the amount of times that there is a neighborhood
                for (int i = 0; i < postalservice.display_counter(); i++){
                    //if there is a home
                    if (postalservice.getNeighborhood(i).homes.size() >= 1){
                        //run for the amount of homes there are in the selected neighborhood
                        for (long unsigned int j = 0; j < postalservice.getNeighborhood(i).homes.size(); j++){
                            //print to a file all of the information that the post office has
                            postalservice.getNeighborhood(i).output(postalservice.getNeighborhood(i), postalservice.getNeighborhood(i).homes[j], outFile);
                        } 
                    }
                    else{
                        //zero homes
                        cout << "There are no homes initialized for neighborhood -> " << postalservice.getNeighborhood(i).getName() << ", could not print homes to file. " << endl;
                    }
                    
                }
                //close the file -> ESSENTIAL
                outFile.close();
                break;
            }
            else{
                cout << "Please select a Neighborhood that you would like to output from. " << endl;
                // print all neighborhoods
                for (int i = 0; i < postalservice.display_counter(); i++){
                    cout << "\t" << i + 1 << ". " << postalservice.getNeighborhood(i).getName() << endl;
                }
                selectneighborhood = 0;
                cin >> selectneighborhood;
                selectneighborhood -= 1;
                // print all homes
                cout << "Please select a Home Owner that you would like to output their home. " << endl;
                for (long unsigned int i = 0; i < postalservice.getNeighborhood(selectneighborhood).homes.size(); i++){
                    cout << "\t" << i + 1 << ". " << postalservice.getNeighborhood(selectneighborhood).homes[i].getAdrs().getAdrsName() << endl;
                }
                selecthome = 0;
                cin >> selecthome;
                selecthome -= 1;
                outFile2.open("FinalProject.txt");
                outFile2 << "\tPost Office General Information Report\t" << endl;
                outFile2 << "--------------------------------------------------" << endl;
                outFile2 << "\tNeighborhood: " << postalservice.getNeighborhood(selectneighborhood).getName() << endl;
                outFile2 << "\t\t------------------------------------------" << endl;  
                //print to a file the exact neighborhood and home
                postalservice.getNeighborhood(selectneighborhood).homes[selecthome].output(outFile2, postalservice.getNeighborhood(selectneighborhood).homes[selecthome]);
                outFile2.close();
                break;
            }

        default:
            break;
        }
    } while (promptselection != 5);
    return 0;
}

/**
 * @brief Prints a given neighborhood and given home
 * 
 * @param neighborhood 
 * @param h1 
 * @param outFile 
 */
void Neighborhood::output(Neighborhood &neighborhood, Home &h1, ofstream &outFile){
    outFile << "\tNeighborhood: " << neighborhood.getName() << endl;
    outFile << "\t\t------------------------------------------" << endl;        
    h1.output(outFile, h1);
}

/**
 * @brief Outputs all the information that the home has 
 * @param outFile 
 * @param h1 
 */
void Home::output(ofstream &outFile, Home &h1){
    outFile << "\t\tAddress: \n\t\t\t" << h1.getAdrs().getAdrsHouse() + " " + h1.getAdrs().getAdrsStreet() + "\n\t\t\t" + h1.getAdrs().getAdrsCity() + ", " + h1.getAdrs().getAdrsState() + " " + h1.getAdrs().getAdrsZip() << endl;
    outFile << "\n\t\tLetters: " << endl;
    if (h1.letters.size() >= 1){
        for (long unsigned int l = 0; l < letters.size(); l++){
            outFile << "\t\t\t**************************************" << endl;
            outFile << "\t\t\tInformation for letter " << endl;
            outFile << "\t\t\tFrom:" << endl;
            outFile << "\t\t\t\t" << letters[l].from.getAdrsName() << "\n\t\t\t\t" << letters[l].from.getAdrsHouse() + " " + letters[l].from.getAdrsStreet() + "\n\t\t\t\t" + letters[l].from.getAdrsCity() + ", " + letters[l].from.getAdrsState() + " " + letters[l].from.getAdrsZip() << endl;
            outFile << "\t\t\tTo:" << endl;
            outFile << "\t\t\t\t" << letters[l].to.getAdrsName() << "\n\t\t\t\t" << letters[l].to.getAdrsHouse() + " " + letters[l].to.getAdrsStreet() + "\n\t\t\t\t" + letters[l].to.getAdrsCity() + ", " + letters[l].to.getAdrsState() + " " + letters[l].to.getAdrsZip() << endl;
            outFile << "\t\t\t\t" << create_barcode(letters[l]) << endl;
            outFile << "\t\t\t**************************************" << endl;
        }
    }
    else{
        outFile << "\t\t\t\tNo letters. " << endl;
    }
}

void PostOffice::prompt(int index){
    string input;
    Home h;
    Address a;
    cout << endl << "Please enter the Home Address Information." << endl << endl;
    cout << "Enter the house number. " << endl;
    while(cin.peek() == '\n'){
        cin.ignore();
    }
    getline(cin, input);
    a.setAdrsHouse(input);
 
    cout << "Enter the street. " << endl;
    getline(cin, input);
    a.setAdrsStreet(input);
 
    cout << "Enter the city. " << endl;
    getline(cin, input);
    a.setAdrsCity(input);
 
    cout << "Enter the state. " << endl;
    getline(cin, input);
    a.setAdrsState(input);
 
    cout << "Enter the zip code. " << endl;
    getline(cin, input);
    a.setAdrsZip(input);
 
    cout << "Enter the name of the home owner. If unsure, type \"unsure\". " << endl;
    getline(cin, input);
    a.setAdrsName(input);
 
    h.setAdrs(a);
    neighborhoods[index].homes.push_back(h);
    if (neighborhoods[index].homes.size() > 1){
        for (long unsigned int i = 0; i < neighborhoods[index].homes.size() - 1; i++){
            if (neighborhoods[index].homes[i] == h){
                cout << "This Home matches an already existing home in this neighborhood" << endl;
                cout << "This Home has been automatically removed from the list of homes." << endl;
                neighborhoods[index].homes.pop_back();
            }else{
                cout << "Successfully added a Home to your Neighborhood." << endl;
            }
        }
    }
    else{
        cout << "Successfully added a Home to your Neighborhood." << endl;
    }
}

bool isText(char line[], bool flag){
    string iterating_character;
    //for 0 less than (length of 5 will always be true because we only call on isText() when the length of zip is 5 characters long)
    for (long unsigned int i = 0; i < 5; i++){
        //if the text doesn't contain alphabetic or alphanumeric
        if (!isalpha(line[i]) || !isalnum(line[i])){
            //then the text is alphabetic and alphanumeric free
            flag = true;
        }      
        //If no essential values match, then there must be a false digit in the zipcode.
        else{
            //determined that the string contains aplhanumeric or alphabetic characters.
            flag = false;
            //Want to immediately return or the code will not return a sentimental value of false.
            return flag;
        }
    }
    return flag;
}

string create_barcode(Letter &ltr){
    int sum = 0;
    string temp;
    char char_arr[5];
    bool flag = true;
    string barcode;
    for (long unsigned int i = 0; i < ltr.to.getAdrsZip().length(); i++){
        sum += stoi(ltr.to.getAdrsZip().substr(i, 1));
    }
    if (ltr.to.getAdrsZip().length() != 5){
        cout << "Zip code " << ltr.to.getAdrsZip() + " is not 5 digits." << endl;
        return "";
    }
    else if (!(isText(strcpy(char_arr, ltr.to.getAdrsZip().c_str()), flag))){
        cout << "Illegal characters in zipcode: " << ltr.to.getAdrsZip() << endl;
        return "";
    }
    else{
        for (long unsigned int i = 0; i < ltr.to.getAdrsZip().length() + 1; i++){
            if (i == 5){
                temp = to_string(calcCheckDigit(sum));
            }
            if (char_arr[i] == '0' || temp == "0"){
                barcode += "||:::";
            }
            if (char_arr[i] == '1' || temp == "1"){
                barcode += ":::||";
            }
            if (char_arr[i] == '2' || temp == "2"){
                barcode += "::|:|";
            }
            if (char_arr[i] == '3' || temp == "3"){
                barcode += "::||:";
            }
            if (char_arr[i] == '4' || temp == "4"){
                barcode += ":|::|";
            }
            if (char_arr[i] == '5' || temp == "5"){
                barcode += ":|:|:";
            }
            if (char_arr[i] == '6' || temp == "6"){
                barcode += ":||::";
            }
            if (char_arr[i] == '7' || temp == "7"){
                barcode += "|:::|";
            }
            if (char_arr[i] == '8' || temp == "8"){
                barcode += "|::|:";
            }
            if (char_arr[i] == '9' || temp == "9"){
                barcode += "|:|::";
            }
        }
    }
    return "Barcode generated. \n\t\t\t|" + barcode + "|";
}

int calcCheckDigit(int sum){
    //If the sum of all the digits of the zipcode is larger than 10, subtract 10
    while (sum > 10){
        sum -= 10;
    }
    //Check digit will always be the number that makes zipcode sum rounded to a 10.
    sum = 10 - sum;
    return sum;
}

Address::Address(string name, string house, string street, string city, string state, string zip){
    name = name;
    house = house;
    city = city;
    state = state;
    zip = zip;
    street = street;
}

Neighborhood::Neighborhood(string name){
    neighborhoodname = name;
}
PostOffice::PostOffice(int neighborhoodcounter){
    neighborhood_counter = neighborhoodcounter;
}

void Neighborhood::prompt(Neighborhood &neighborhood, Home &h1){
    string input;
    Letter l;
    Address a;
    Address a2;

    a2.setAdrsHouse(h1.getAdrs().getAdrsHouse());
    a2.setAdrsCity(h1.getAdrs().getAdrsCity());
    a2.setAdrsState(h1.getAdrs().getAdrsState());
    a2.setAdrsStreet(h1.getAdrs().getAdrsStreet());
    a2.setAdrsName(h1.getAdrs().getAdrsName());
    a2.setAdrsZip(h1.getAdrs().getAdrsZip());
       
    cout << endl << "Please enter the \"FROM\" letter information." << endl << endl;
    cout << "Enter the house number. " << endl;
    while (cin.peek() == '\n'){
        cin.ignore();
    }
    
    getline(cin, input);
    a.setAdrsHouse(input);
    cout << "Enter the street. " << endl;
    getline(cin, input);
    a.setAdrsStreet(input);
    cout << "Enter the city. " << endl;
    getline(cin, input);
    a.setAdrsCity(input);
    cout << "Enter the state. " << endl;
    getline(cin, input);
    a.setAdrsState(input);
    cout << "Enter the zip code. " << endl;
    getline(cin, input);
    a.setAdrsZip(input);
    cout << "Enter the name of the sender. If unsure, type \"unsure\". " << endl;
    getline(cin, input);
    a.setAdrsName(input);
    l.from = a;
    l.to = a2;
    h1.setLetter(l);
    cout << endl;
}

bool Home::operator == (Home h1){
    return (getAdrs().getAdrsName() == h1.getAdrs().getAdrsName()) && (getAdrs().getAdrsHouse() == h1.adrs.getAdrsHouse()) && (getAdrs().getAdrsCity() == h1.adrs.getAdrsCity()) && 
           (getAdrs().getAdrsState() == h1.getAdrs().getAdrsState()) && (getAdrs().getAdrsStreet() == h1.adrs.getAdrsStreet()) && (getAdrs().getAdrsZip() == h1.adrs.getAdrsZip());
}