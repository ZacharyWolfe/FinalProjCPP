#ifndef PROJECT5_H
#define PROJECT5_H
 
class Address{
    public:
        //constructor
        Address(std::string name = "", std::string house = "", std::string street = "", std::string city = "", std::string state = "", std::string zip = "");
       
        //getters
        std::string getAdrsName(){return name;}
        std::string getAdrsHouse(){return house;}
        std::string getAdrsCity(){return city;}
        std::string getAdrsState(){return state;}
        std::string getAdrsZip(){return zip;}
        std::string getAdrsStreet(){return street;}
 
        //setters
        void setAdrsName(std::string input){name = input;}
        void setAdrsHouse(std::string input){house = input;}
        void setAdrsCity(std::string input){city = input;}
        void setAdrsState(std::string input){state = input;}
        void setAdrsZip(std::string input){zip = input;}
        void setAdrsStreet(std::string input){street = input;}
    private:
        // private data
        std::string name;
        std::string house;
        std::string city;
        std::string state;
        std::string zip;
        std::string street;
};
class Letter{
    public:
        Address from;
        Address to;
        std::string barcode;
};
 
class Home{
    public:
        // constructor
        Home(){letters.reserve(20);}

        //overloaded operator
        bool operator == (Home h1);

        // getters
        Address getAdrs(){return adrs;}
 
        // setters
        void setLetter(Letter l){letters.push_back(l);}
        int getLetterSize(){return letters.size();}
        void setAdrs(Address a){adrs = a;}
 
        // output
        void output(std::ofstream &outFile, Home &h1);
 
    private:
        Address adrs;
        std::vector<Letter> letters;
};
 
class Neighborhood{
    public:
        std::vector<Home> homes;

        // constructor
        Neighborhood(std::string name = "");

        void prompt(Neighborhood &neighborhood, Home &h1);
        // getters
        std::string getName(){return neighborhoodname;}
 
        // setters
        void setName(std::string input){neighborhoodname = input;}
       
        // output
        void output(Neighborhood &neighborhood, Home &h1, std::ofstream &outFile);
    private:
        std::string neighborhoodname;
};
 
class PostOffice{
    public:
        static const int SIZE = 5;
        PostOffice(int neighborhoodcounter = 0);
        // getters
        int display_counter(){return neighborhood_counter;}
        Neighborhood& getNeighborhood(int input){return neighborhoods[input];}
 
        // setters
        void inc_counter(){neighborhood_counter += 1;}
        void setName(std::string input){neighborhoods[neighborhood_counter].setName(input);}
 
        // output
        void prompt(int index);
 
    private:
        int neighborhood_counter = 0;
        Neighborhood neighborhoods[5];
};
 
#endif

